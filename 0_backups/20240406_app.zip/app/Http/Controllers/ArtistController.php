<?php

namespace App\Http\Controllers;

use App\Models\Artist;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class ArtistController extends Controller {

    public function index(): View {
        return view('artists', ['artists' => Artist::all()->sortBy('artist')]);
    }

    public function artist(string $alias): View {
        $artist = Artist::with(['albums', 'albums.relationships', 'albums.artists'])->where('alias', $alias)->firstOrFail();
        return view('artist', [
            'artist' => $artist, 
            'albums' => $artist->albums, 
            //'numberOfSongs' => $artist->getNumberOfSongs(), 
            //'songs' => $artist->songs()
        ]);
    }
    
}
